﻿var imageModule = angular.module('imgModule', []);

imageModule.provider('imgprovide', function () {

    var Banner = '';
    var Logo = '';



    this.setLogo = function () {


        this.logo = value;
    }

    this.$get = function () {

        return {

            Logo: logo

        };

    }
});


imageModule.config(function (imageProvider) {
    imageProvider.setLogo('Images/images.png');



});