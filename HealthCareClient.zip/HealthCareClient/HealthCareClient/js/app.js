﻿$(document).ready(function () {
    console.log("Jquery ready");
    $.ajax({
        url: "http://localhost:37694/api/C1265365Insurance",
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            console.log(response);

            thead = $('<thead></thead>').appendTo("#my-table");
            row = $('<tr></tr>').appendTo(thead);
            th = $('<th></th>').text("InsuranceId").appendTo(row);
            th = $('<th></th>').text("Name").appendTo(row);
            tbody = $('<tbody></tbody>').appendTo("#my-table");
            $.each(JSON.parse(response), function (item, value) {


                row = $('<tr></tr>').appendTo(tbody);
                td = $('<td></td>').appendTo(row);
                $('<a></a>').text(value.InsuranceId).appendTo(td);
                $('<td></td>').text(value.Name).appendTo(row);






            });

            $('#my-table')
                .tablesorter({
                    theme: 'blue',
                    widget: ['zebra']
                });

            $('#my-table').bdt();

        }
    });

});