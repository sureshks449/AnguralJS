﻿var appModule = angular.module('InsModule', []);

appModule.controller('InsController', ['$scope', function ($scope) {
    console.log('Controler Loaded!')

    $scope.Customer = {

        id: 0,
        Name: '',
        DOB:new Date()

    }

    $scope.Save = function () {

        console.log($scope.Customer.id,'' ,$scope.Customer.Name,'' ,$scope.Customer.DOB);

    }

}]);