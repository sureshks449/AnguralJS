﻿$(document).ready(function () {
    $.ajax
     ({
         url: "http://localhost:58114/Insurance",
         type: "GET",
         datatype: "json",

         success: function (response) {

             if (typeof (response) != 'object') {
                 x = JSON.parse(response);
             } else {
                 x = response;
             }
        //Headers
             var row = $('<tr></tr>').appendTo('#HCDATA')

             $.each(x[0], function (key, value) {
                 var col = $('<td></td>').text(key).appendTo(row);
             });

             //RowData
             $.each(x, function (key, value) {
                 var row = $('<tr></tr>').appendTo('#HCDATA')
                 console.log(key, value);
                 $.each(value, function (item, data) {
                     var col = $('<td></td>').text(data).appendTo(row);
                     console.log(data);
                 });
             });

             $('#HCDATA').tablesorter({
                 theme: 'blue',
                 Widget:['Zebra']

             });

             $('#HCDATA').bdt();

         },
         error: function (response) {
             console.log(response);
         }
     });
});

