﻿var serviceM = angular.module('ServiceModule', []);

serviceM.service('InsuranceService', ['$http', function ($http) {
    var serviceCollection = function () {
        return $http({

            method: 'GET',
            dataType: 'jsonp',
            headers: {

                'Content-Type': 'application/x-www-form-urlencoded',
            },
            url: 'http://localhost:58114/Insurance/Index'

        }).then(function (info) {

            console.log('Resolved');
            return info;

        });
    }
    return {

        InsurenceServiceObj: serviceCollection
    }
}]);

serviceM.service('PatientService', ['$http', function ($http) {

    var serviceCollection = function () {
        return $http({
            method: 'GET',
            dataType: 'jsonp',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            url: 'http://localhost:58114/Insurance/PatientData'

        }).then(function (info) {
            console.log('Resolved');
            return info;
        });
    }
    return {

        PatientServiceObj: serviceCollection
    }
}]);




