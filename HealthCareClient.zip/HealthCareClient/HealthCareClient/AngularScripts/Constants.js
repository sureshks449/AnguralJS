﻿var constantModule = angular.module('ConstModule', [])

constantModule.constant('Options', ['Insurance','Inventory','Patient','Users','Roles']);