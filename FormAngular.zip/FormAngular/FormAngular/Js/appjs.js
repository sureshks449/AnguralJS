﻿var formModule = angular.module('formModule', ['ngMessages']);

formModule.controller('formCtrl', function ($scope, $http) {

    console.log('COntroller ----------')

    $scope.Insmodel = {
        InsurenceCode: '',
        InsuranceId: 0,
        Name: '',
        phoneNo: '',
        Address: '',
        Email: '',
        SumAssured: 0,
        Premium: 0,
        Nominee: '',
        Mobile: '',
        DateOfServise: new Date()
    }

    $scope.submit = function () {

        console.log($scope.Insmodel);


        $http(
            {
                method: 'post',
                datatype: 'jasonp',
                params: { Data: $scope.Insmodel },
                headers: {
                    'Content-Type': 'application/json'
                },
                url: 'http://localhost:61402/api/Insurance',


            }).then(function (response) {

                console.log(response);

            })
    }



});